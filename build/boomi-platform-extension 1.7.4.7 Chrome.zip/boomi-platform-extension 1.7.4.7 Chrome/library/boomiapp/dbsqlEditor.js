document.arrive(".inline_script_editor_header", function (arrsqlEditor) {
  arrsqlEditor.parentNode.classList.add("flex_panel_sql");
});
