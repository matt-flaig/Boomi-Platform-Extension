
const add_canvase_listener = (canvas) => {

    if (BoomiPlatform.canvas_grid == 'off'){
        let xpanel = document.getElementsByClassName("canvas_grid");
        xpanel[0].classList.add('canvasNew')
    }
    }