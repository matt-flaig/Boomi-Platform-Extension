/*------Global------*/
//Variables
var headerVisible = false;





